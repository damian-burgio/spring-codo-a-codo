package agencias.service.models.enums;

public enum ERol {

    ADMIN,
    USER,
    AGENTE_VENTAS
}
