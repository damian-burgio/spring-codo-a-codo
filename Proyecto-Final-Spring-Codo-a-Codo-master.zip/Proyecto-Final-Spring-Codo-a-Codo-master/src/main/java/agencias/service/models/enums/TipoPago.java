package agencias.service.models.enums;

public enum TipoPago {
    TARJETA_CREDITO,
    TRANSFERENCIA,
    PAGO_ONLINE

}
