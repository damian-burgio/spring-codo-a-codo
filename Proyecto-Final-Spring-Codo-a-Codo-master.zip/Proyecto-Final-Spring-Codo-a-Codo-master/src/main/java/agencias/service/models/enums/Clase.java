package agencias.service.models.enums;

public enum Clase {
    ECONOMIC,
    BUSINESS,
}
