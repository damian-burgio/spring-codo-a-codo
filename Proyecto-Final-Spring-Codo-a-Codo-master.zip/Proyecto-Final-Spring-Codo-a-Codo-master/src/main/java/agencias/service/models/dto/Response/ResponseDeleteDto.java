package agencias.service.models.dto.Response;

import lombok.*;

@Data
@AllArgsConstructor
public class ResponseDeleteDto {
    public String mensaje;
}
