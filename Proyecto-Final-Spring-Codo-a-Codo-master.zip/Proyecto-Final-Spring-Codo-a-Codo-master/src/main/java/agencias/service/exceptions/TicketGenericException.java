package agencias.service.exceptions;

public class TicketGenericException extends RuntimeException {

    public TicketGenericException(String message) {
        super(message);
    }
}
