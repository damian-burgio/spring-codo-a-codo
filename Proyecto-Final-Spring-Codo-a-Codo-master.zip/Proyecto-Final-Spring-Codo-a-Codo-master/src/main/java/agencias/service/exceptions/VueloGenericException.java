package agencias.service.exceptions;

public class VueloGenericException extends RuntimeException{

    public VueloGenericException(String message) {
        super(message);
    }
}
