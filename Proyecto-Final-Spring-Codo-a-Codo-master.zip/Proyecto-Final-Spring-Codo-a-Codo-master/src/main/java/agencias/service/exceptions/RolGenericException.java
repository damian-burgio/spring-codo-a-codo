package agencias.service.exceptions;

public class RolGenericException extends RuntimeException {

    public RolGenericException(String message) {
        super(message);
    }
}
